HPDATA = 'http://www.hp.com/netconf/data:1.0'
HPDATA_C = '{' + HPDATA + '}'

NETCONFBASE = "urn:ietf:params:xml:ns:netconf:base:1.0"
NETCONFBASE_C = '{' + NETCONFBASE + '}'

HPCONFIG = "http://www.hp.com/netconf/config:1.0"
HPCONFIG_C = '{' + HPCONFIG + '}'

HPACTION = "http://www.hp.com/netconf/action:1.0"
HPACTION_C = '{' + HPACTION + '}'
